Core/Src/OLED_fonts.o: ../Core/Src/OLED_fonts.c ../Core/Inc/OLED_fonts.h \
 ../Core/Inc/OLED_conf.h
../Core/Inc/OLED_fonts.h:
../Core/Inc/OLED_conf.h:
